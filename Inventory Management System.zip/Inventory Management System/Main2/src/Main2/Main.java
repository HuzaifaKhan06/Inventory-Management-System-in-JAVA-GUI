package Main2;

import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;

import javax.swing.*;

public class Main extends JFrame {
    // Symptoms of piles
    private String[] pilesSymptoms = {
            "painful lumps in and around the anus",
            "itching and discomfort around the anus",
            "discomfort during and after passing stools",
            "bloody stools"
    };

    // Symptoms of malaria
    private String[] malariaSymptoms = {
            "shaking chills that can range from moderate to severe",
            "high fever",
            "profuse sweating",
            "headache",
            "nausea",
            "vomiting",
            "abdominal pain",
            "diarrhea",
            "anemia",
            "muscle pain",
            "convulsions",
            "coma",
            "bloody stools"
    };

    private String[] tbSymptoms = {
            "a persistent cough that lasts more than 3 weeks and usually brings up phlegm, which may be bloody",
            "weight loss",
            "night sweats",
            "high temperature",
            "tiredness and fatigue",
            "loss of appetite",
            "swellings in the neck"
    };

    private String[] typhoidSymptoms = {
            "Fever that starts low and increases daily, possibly reaching as high as 104.9 F (40.5 C)",
            "Headache",
            "Weakness and fatigue",
            "Muscle aches",
            "Sweating",
            "Dry cough",
            "Loss of appetite and weight loss",
            "Stomach pain",
            "Diarrhea or constipation",
            "Rash",
            "Extremely swollen stomach"
    };

    private String[] ihdSymptoms = {
            "Neck or jaw pain",
            "Shoulder or arm pain",
            "A fast heartbeat",
            "Shortness of breath when you are physically active",
            "Nausea and vomiting",
            "Sweating",
            "Fatigue"
    };



    private String[] ihdTreatment = {
            "1 Eat a healthy, balanced diet",
            "2 Be more physically active",
            "3 Keep to a healthy weight",
            "4 Give up smoking",
            "5 Reduce your alcohol consumption",
            "6 Keep your blood pressure under control",
            "7 Keep your diabetes under control",
            "8 Take any prescribed medicine"
    };


    private String[] typhoidTreatment = {
            "1 Safe drinking water, improved sanitation and adequate medical care",
            "2 Vaccines"
    };


    private String[] tbTreatment = {
            "Isoniazid INH in combination with three other drugs—rifampin, pyrazinamide and ethambutol"
    };

    // Treatment options for piles
    private String[] pilesTreatment = {
            "1 Eating a healthful diet",
            "2 Avoiding straining when passing stools",
            "3 Avoiding heavy lifting",
            "4 Maintaining a moderate weight",
            "5 Staying active"
    };

    // Treatment options for malaria
    private String[] malariaTreatment = {
            "1 Anti-malaria medication",
            "2 Bed rest",
            "3 Fluids to prevent dehydration"
    };



    private JPanel mainPanel, symptomsPanel, buttonPanel;
    private JLabel chooseDiseaseLabel, symptomsLabel;
    private JComboBox<String> diseaseList;
    private JCheckBox[] symptomCheckBoxes;
    private JButton submitButton;
    private JFrame frame;
    public Main() {
        setTitle("Disease Diagnosis");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);

        frame =new JFrame();
        frame.setSize(900,900);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        mainPanel.setSize(500,500);

        chooseDiseaseLabel = new JLabel("Choose a Disease:");
        diseaseList = new JComboBox<>(new String[] {"Piles", "Malaria","tb","typhoid","ihd"});

        symptomsPanel = new JPanel();
        symptomsPanel.setLayout(new BoxLayout(symptomsPanel, BoxLayout.PAGE_AXIS));
        symptomsLabel = new JLabel("Select Symptoms:");

        symptomCheckBoxes = new JCheckBox[pilesSymptoms.length];
        for (int i = 0; i < pilesSymptoms.length; i++) {
            symptomCheckBoxes[i] = new JCheckBox(pilesSymptoms[i]);
        }

        diseaseList.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                symptomsPanel.removeAll();
                symptomsPanel.add(symptomsLabel);
                if (diseaseList.getSelectedItem().equals("Piles")) {
                    symptomCheckBoxes = new JCheckBox[pilesSymptoms.length];
                    for (int i = 0; i < pilesSymptoms.length; i++) {
                        symptomCheckBoxes[i] = new JCheckBox(pilesSymptoms[i]);
                        symptomsPanel.add(symptomCheckBoxes[i]);
                    }
                } else if (diseaseList.getSelectedItem().equals("Malaria")) {
                    symptomCheckBoxes = new JCheckBox[malariaSymptoms.length];
                    for (int i = 0; i < malariaSymptoms.length; i++) {
                        symptomCheckBoxes[i] = new JCheckBox(malariaSymptoms[i]);
                        symptomsPanel.add(symptomCheckBoxes[i]);
                    }
                }
                else if (diseaseList.getSelectedItem().equals("tb")) {
                    symptomCheckBoxes = new JCheckBox[tbSymptoms.length];
                    for (int i = 0; i < tbSymptoms.length; i++) {
                        symptomCheckBoxes[i] = new JCheckBox(tbSymptoms[i]);
                        symptomsPanel.add(symptomCheckBoxes[i]);
                    }
                }

                else if (diseaseList.getSelectedItem().equals("typhoid")) {
                    symptomCheckBoxes = new JCheckBox[typhoidSymptoms.length];
                    for (int i = 0; i < typhoidSymptoms.length; i++) {
                        symptomCheckBoxes[i] = new JCheckBox(typhoidSymptoms[i]);
                        symptomsPanel.add(symptomCheckBoxes[i]);
                    }
                }

                else if (diseaseList.getSelectedItem().equals("ihd")) {
                    symptomCheckBoxes = new JCheckBox[ihdSymptoms.length];
                    for (int i = 0; i < ihdSymptoms.length; i++) {
                        symptomCheckBoxes[i] = new JCheckBox(ihdSymptoms[i]);
                        symptomsPanel.add(symptomCheckBoxes[i]);
                    }
                }


                symptomsPanel.revalidate();
                symptomsPanel.repaint();
            }
        });

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] selectedSymptoms;
                String[] symptoms;
                String[] treatment;
                if (diseaseList.getSelectedItem().equals("Piles")) {
                    symptoms = pilesSymptoms;
                    treatment = pilesTreatment;
                }
                else if (diseaseList.getSelectedItem().equals("tb")){
                    symptoms=tbSymptoms;
                    treatment=tbTreatment;
                }

                else if (diseaseList.getSelectedItem().equals("typhoid")){
                    symptoms=typhoidSymptoms;
                    treatment=typhoidTreatment;
                }

                else if (diseaseList.getSelectedItem().equals("ihd")){
                    symptoms=ihdSymptoms;
                    treatment=ihdTreatment;
                }

                else {
                    symptoms = malariaSymptoms;
                    treatment = malariaTreatment;
                }

                int count = 0;
                for (JCheckBox checkBox : symptomCheckBoxes) {
                    if (checkBox.isSelected()) {
                        count++;
                    }
                }

                if ((double)count / symptoms.length > 0.75) {
                    String treatmentOptions = "";
                    for (String option : treatment) {
                        treatmentOptions += option + "\n";
                    }

                    JOptionPane.showMessageDialog(null, "The decease is severe \n Treatment options for "+ diseaseList.getSelectedItem()+" :\n" + treatmentOptions);
                } else if ((double)count / symptoms.length > 0.5){
                    String treatmentOptions = "";
                    for (String option : treatment) {
                        treatmentOptions += option + "\n";
                    }
                    JOptionPane.showMessageDialog(null, "The decease is Moderate \n Treatment options for "+ diseaseList.getSelectedItem()+" :\n" + treatmentOptions);
                }else {
                    JOptionPane.showMessageDialog(null, "You may have a different disease, please consult a doctor for proper diagnosis.");
                }
            }
        });


        mainPanel.add(chooseDiseaseLabel);
        mainPanel.add(diseaseList);
        mainPanel.add(symptomsPanel);

        buttonPanel = new JPanel();
        buttonPanel.add(submitButton);

        mainPanel.add(buttonPanel);

        add(mainPanel);
        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        new Main();
    }
}