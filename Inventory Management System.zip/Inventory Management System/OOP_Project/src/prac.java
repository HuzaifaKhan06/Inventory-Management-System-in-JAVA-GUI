import java.util.Scanner;
public class prac {
    public static void main(String[] args) {
   int a;
   int b;
   Scanner sc = new Scanner(System.in);
      /*  System.out.println("WEnter value of A ");
   a=sc.nextInt();
        System.out.println("Enter value of B");
        b=sc.nextInt();
        System.out.println("sum of two numbers is : "+ (a+b));
        System.out.println(" ....................");
        if (a>b)
        {
            System.out.println(" A is greater then  B");
        }
        else if (b>a)
        {
            System.out.println("B is Greater Then A");
        }
        else
        {
            System.out.println(" Numbers Are Equal ");
        }
        */
        System.out.println(" ...................... LOOPS ..................");
        for (int i=0; i<=5;i++)
        {
            System.out.println(i);
        }
        
}
}
